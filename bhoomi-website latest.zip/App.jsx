import React from "react";

function App() {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h1 style={{ fontSize: "3rem", color: "#22543d" }}>BHOOMI</h1>
      <p style={{ fontStyle: "italic", color: "#38a169" }}>
        “भूमि — स्वाद और सेहत, दोनों की गारंटी।”
      </p>
      <p style={{ marginTop: "2rem", fontSize: "1.2rem" }}>
        Delivering Excellence in Pulses & Oil since 1977.
      </p>
    </div>
  );
}

export default App;